# Design System: Command & Sovereignty

## 1. Overview & Creative North Star: "The Obsidian Monolith"
This design system rejects the "flat" utility of modern web applications in favor of a "Minor House" command center aesthetic. Our Creative North Star is **The Obsidian Monolith**: an interface that feels carved from planetary stone and reinforced with high-frequency light. 

To achieve a cinematic, atmospheric feel, we move beyond the standard grid. We embrace **brutalist precision**—where every element feels heavy, intentional, and ancient—interspersed with **weightless holographic overlays**. The layout should feel like a tactical map projected onto a sandstone wall: technical, noble, and deeply atmospheric. We utilize sharp, zero-radius corners and dramatic tonal shifts to define a space that is both a war room and a throne room.

---

## 2. Colors: The Palette of Arrakis
Our color strategy mimics the interplay between warm, subterranean stone and the cold flicker of Holtzman-effect technology.

### The "No-Line" Rule
**Borders are forbidden.** We define the architecture of the screen through color-blocking and tonal transition. To separate a tactical readout from the main console, place a `surface_container_high` element against a `surface` background. The eye should perceive the edge through the shift in luminance, not a 1px stroke.

### Surface Hierarchy & Nesting
Treat the UI as a physical console. 
*   **Base Layer:** `surface` (#17130f) – The deep, warm shadows of the command chamber.
*   **Recessed Modules:** `surface_container_lowest` (#110e0a) – Use this for inset data feeds or "carved" input areas.
*   **Primary Controls:** `surface_container_high` (#2e2925) – Use for floating command cards.

### The "Glass & Gradient" Rule
To capture the "holographic" quality of the Dune aesthetic, the `secondary` (#77d4ea) and `secondary_container` (#008094) colors must be used as light-emitting sources. 
*   **Holographic Overlays:** Apply `surface_variant` with a 60% opacity and a `24px` backdrop-blur to create "glass" panels that catch the warm light of the background.
*   **Signature Gradients:** Use a linear gradient from `primary` (#f5bb81) to `primary_container` (#c28e58) at 135° for high-level tactical CTAs to simulate the glint of polished brass or spice-infused metal.

---

## 3. Typography: The Script of the Imperium
The typography balance reflects the duality of the system: **Space Grotesk** for the hard, technical hardware; **Manrope** for the noble, human element; and **Inter** for the microscopic telemetry.

*   **Display & Headlines (Space Grotesk):** These are your architectural anchors. Use `display-lg` for planetary designations and `headline-md` for system status. The wide, technical stance of Space Grotesk should feel like it was etched by a laser into a metal bulkhead.
*   **Titles & Body (Manrope):** Use Manrope for high-level intelligence reports. Its geometric but friendly nature ensures readability amidst the technical "noise."
*   **Labels (Inter):** Reserved for technical readouts, coordinates, and micro-data. Use `label-sm` in `secondary` (#77d4ea) to mimic glowing CRT or holographic text.

---

## 4. Elevation & Depth: Tonal Sculpting
In a world of sandstone and metal, shadows are not "fuzzy"—they are ambient occlusions.

*   **The Layering Principle:** Avoid shadows for elevation. Instead, use "stacking." A `surface_container_highest` card sitting on a `surface` background provides all the "lift" required.
*   **Ambient Shadows:** If an element must "float" (like a holographic modal), use a shadow tinted with `surface_tint` (#f5bb81) at 5% opacity. This simulates the warm ambient glow of the command center reflecting off the surface.
*   **The "Ghost Border" Fallback:** If accessibility requires a boundary, use `outline_variant` (#50453a) at 15% opacity. It should be felt, not seen.
*   **Zero Radius:** All elements (Cards, Buttons, Inputs) must use **0px roundedness**. Rounded corners are a sign of soft, civilian design; our House demands the sharp, uncompromising edges of military discipline.

---

## 5. Components

### Buttons: Tactical Actuators
*   **Primary:** Background `primary` (#f5bb81), Text `on_primary` (#492900). No border. On hover, shift to `primary_container`.
*   **Secondary (Holographic):** Background `transparent`, Border 1px `secondary` (#77d4ea) at 40% opacity. Text `secondary`.
*   **Tertiary:** Text `on_surface_variant`, no background. For low-priority navigation.

### Input Fields: Data Lithographs
*   **Field:** Background `surface_container_lowest`. A 2px bottom-accent of `outline` (#9d8e81).
*   **Focus State:** The bottom accent glows `secondary` (#77d4ea) with a subtle outer glow (4px blur).

### Cards & Lists: Module Blocks
*   **No Dividers:** Lists are separated by 8px or 16px of vertical space. 
*   **Header Blocks:** Use `surface_container_highest` for the header of a card and `surface_container` for the body to create a "stepped" physical appearance.

### Tactical Chips
*   Used for status (e.g., "SHIELD ACTIVE"). Use `secondary_container` with `on_secondary_container` text. Keep them rectangular and stark.

### Additional Component: "The Monolith Loader"
*   Instead of a spinning circle, use a series of expanding and contracting vertical bars of varying heights in `primary`, mimicking a seismic frequency or spice-density reading.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Asymmetry:** Place a large `display-lg` title in the top left, but balance it with a small, dense `label-sm` data cluster in the bottom right.
*   **Embrace "Dead Space":** Allow the `surface` color to breathe. Large gaps between containers simulate the vastness of deep-space command.
*   **Treat Light as Information:** Use the blue `secondary` color only for active, technical, or holographic data. Everything else stays in the warm "sandstone" `primary` spectrum.

### Don’t:
*   **No Rounded Corners:** Ever. A single 4px radius breaks the entire "Minor House" aesthetic.
*   **No Pure Greys:** Never use `#888888`. All neutrals must be tinted with the warmth of `#17130f` or the cool of `#77d4ea`.
*   **No Standard Shadows:** Do not use default CSS shadows. They look like "web" shadows. Use tonal layering or tinted, wide-spread blurs.
*   **No Centered Layouts:** Avoid centering everything. Command centers are functional; layouts should feel like they are optimized for a multi-monitor tactical array.